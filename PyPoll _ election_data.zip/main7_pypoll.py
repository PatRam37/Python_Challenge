# Calculate winner in Election and total percentage and number of votes per candidate
import os
import csv

filepath = os.path.join ("election_data.csv")

# Open and read csv
with open (filepath) as election_data:
    csv_reader = csv.reader(election_data, delimiter=",")     
    header = next(csv_reader)
    # print(f"Header: {header}")
    
    total_votes = 0
    
    candidate_dict = {}
    
    key_max_value = ""

    for row in csv_reader:
       
        total_votes +=1        
        candidate = row[2]
        # print(candidate)

        if candidate in candidate_dict:
            candidate_dict[candidate] +=1
        else:
            candidate_dict[candidate] = 1
    
    key_max_value=max(candidate_dict, key=candidate_dict.get)

#print(f"Candidate dictionary {candidate_dict}")

print()
print("Election Results")
print("------------------------------")
print (f"Total Votes: {total_votes}")
print("-------------------------------")
for key, value in candidate_dict.items():
    print (f"{key}: {round(((value/total_votes)*100),3)}% ({value})")
print("--------------------------------")
print (f"Winner: {key_max_value}")
print("--------------------------------")
print()

